import { PaginationRequestDTO } from "src/common/application/services/dto/request/pagination-request-dto";

export interface FindAllCuponsApplicationRequestDTO extends PaginationRequestDTO {
    // Puede incluir filtros adicionales en el futuro (opcional)
}
