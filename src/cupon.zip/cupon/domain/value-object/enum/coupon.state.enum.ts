export enum CouponStateEnum{
    avaleable="avaleable",
    unavaleable="unavaleable",
}