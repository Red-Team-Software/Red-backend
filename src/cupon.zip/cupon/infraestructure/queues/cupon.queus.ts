export const CuponQueues = [
    { name: 'OrderEvents/OrderRegistered', pattern: 'OrderRegistered' }
]